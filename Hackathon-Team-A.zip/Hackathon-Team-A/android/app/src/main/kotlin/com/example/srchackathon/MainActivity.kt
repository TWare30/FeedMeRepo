package com.example.srchackathon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
