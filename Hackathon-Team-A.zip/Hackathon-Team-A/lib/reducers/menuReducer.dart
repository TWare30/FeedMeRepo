import '../store/AppState.dart';
import 'actions.dart';

AppState menuReducer(AppState state, action){
  switch(action['type']){
    case actionTypes.MENU_LOADED:
      state.menu = action['menu'];
      return state;
    default:
      return state;
  }
}