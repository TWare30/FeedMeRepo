import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:srchackathon/store/AppState.dart';
import 'assignmentActionReducer.dart';
import 'cartReducer.dart';
import 'caseReducer.dart';
import 'menuReducer.dart';

final AppReducer = combineReducers<AppState>([
  assignmentActionReducer,
  cartReducer,
  caseReducer,
  menuReducer,

]);