import '../store/AppState.dart';
import 'actions.dart';

AppState assignmentActionReducer(AppState state, action){
  switch(action['type']){
    case actionTypes.ASSIGNMENT_ACTION_LOADED:
      state.currentAction = action['currentAction'];
      return state;
    default:
      return state;
  }
}