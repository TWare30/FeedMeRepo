import '../store/AppState.dart';
import 'actions.dart';

AppState cartReducer(AppState state, action){
  switch(action['type']){
    case actionTypes.CART_ADD_ITEM:
      state.cart.items.add(action['item']);
      state.cart.caculateSubtotal();
      return state;
    case actionTypes.CART_REMOVE_ITEM:
      return state;
    default:
      return state;
  }
}