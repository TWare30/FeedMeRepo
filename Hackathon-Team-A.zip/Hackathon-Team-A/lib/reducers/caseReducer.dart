import '../store/AppState.dart';
import 'actions.dart';

AppState caseReducer(AppState state, action){
  switch(action['type']){
    case actionTypes.CASE_LOADED:
      state.currentCase = action['currentCase'];
      return state;
    default:
      return state;
  }
}