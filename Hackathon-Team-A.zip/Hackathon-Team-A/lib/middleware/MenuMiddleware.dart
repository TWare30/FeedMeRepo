import 'package:redux/redux.dart';
import 'package:srchackathon/models/flutter/MenuData.dart';
import 'package:srchackathon/reducers/actions.dart';
import 'package:srchackathon/utils/API.dart';

MenuMiddleware(Store store, action, NextDispatcher next){
  switch(action['type']){
    case actionTypes.MENU_REQUEST:
      API.loadMenu(action['restaurantID']).then(
        (menuJson) {
          MenuData menu = MenuData.fromMap(menuJson);
          next({
            'type': actionTypes.MENU_LOADED,
            'menu': menu
          });
        }
      );
      break;
    default:
      next(action);
  }
}