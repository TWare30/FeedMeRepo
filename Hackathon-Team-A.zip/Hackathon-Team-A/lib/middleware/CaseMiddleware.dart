import 'package:redux/redux.dart';
import 'package:srchackathon/models/pega/CaseData.dart';
import 'package:srchackathon/reducers/actions.dart';
import 'package:srchackathon/utils/API.dart';

CaseMiddleware(Store store, action, NextDispatcher next){
  switch(action['type']){
    case actionTypes.CASE_REQUEST:
      API.getCase(action['caseID']).then(
              (caseJson){
            CaseData caseData = CaseData.fromMap(caseJson);
            next({
              'type': actionTypes.CASE_LOADED,
              'currentCase': caseData
            });
          }
      );
      break;
    default:
      next(action);
  }
}