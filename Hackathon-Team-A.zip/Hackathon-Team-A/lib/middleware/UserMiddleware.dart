import 'package:redux/redux.dart';
import 'package:srchackathon/models/flutter/User.dart';
import 'package:srchackathon/reducers/actions.dart';
import 'package:srchackathon/utils/API.dart';

UserMiddleware(Store store, action, NextDispatcher next){
  switch(action['type']){
    case actionTypes.LOGIN_REQUEST:
      API.login(action['username'], action['password']).then(
            (userJson){
            User user = User.fromMap(userJson);
            next({
              'type': actionTypes.LOGIN_SUCCESS,
              'user': user
            });
          }
      );
      break;
    default:
      next(action);
  }
}