import 'package:redux/redux.dart';
import 'package:srchackathon/models/pega/AssignmentAction.dart';
import 'package:srchackathon/reducers/actions.dart';
import 'package:srchackathon/utils/API.dart';

AssignmentActionMiddleware(Store store, action, NextDispatcher next){
  switch(action['type']){
    case actionTypes.ASSIGNMENT_ACTION_REQUEST:
      API.getAssignmentAction(action['assignmentID'], action['actionID']).then(
              (actionJson){
            AssignmentAction actionData = AssignmentAction.fromMap(actionJson);
            next({
              'type': actionTypes.ASSIGNMENT_ACTION_LOADED,
              'currentAction': actionData
            });
          }
      );
      break;
    default:
      next(action);
  }
}