import 'AssignmentActionMiddleware.dart';
import 'CaseMiddleware.dart';
import 'MenuMiddleware.dart';
import 'package:redux/redux.dart';

List<Middleware> AppMiddleware(){
  return [
    CaseMiddleware,
    AssignmentActionMiddleware,
    MenuMiddleware
  ];
}