import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:srchackathon/utils/API.dart';
import 'package:srchackathon/widgets/Root.dart';
import 'reducers/AppReducer.dart';
import 'store/AppState.dart';
import 'middleware/Middleware.dart';
import 'utils/theme.dart';

void main() {

  final store = Store<AppState>(
    AppReducer,
    middleware: AppMiddleware(),
    initialState: initializeState(),
  );

  API.setCredentials('ryan.dougherty', r'rules123$');

  runApp(StoreProvider(
      store: store,
      child: MaterialApp(
        title: 'Hackathon 2022',
        theme: AppTheme(),
        home: Root(),
      )
  ));
}



