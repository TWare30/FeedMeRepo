import 'package:srchackathon/models/flutter/MenuData.dart';
import 'package:srchackathon/models/flutter/User.dart';
import 'package:srchackathon/models/flutter/Cart.dart';
import 'package:srchackathon/models/pega/AssignmentAction.dart';
import 'package:srchackathon/models/pega/CaseData.dart';


class AppState {
  CaseData? currentCase;
  AssignmentAction? currentAction;
  User? user;
  MenuData? menu;
  Cart cart = Cart();
}

AppState initializeState(){
  AppState appState = AppState();
  return appState;
}