import 'package:flutter/widgets.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:srchackathon/models/flutter/User.dart';
import 'package:srchackathon/store/AppState.dart';
import 'package:srchackathon/widgets/CustomerHome.dart';
import 'package:srchackathon/widgets/DriverHome.dart';
import 'package:srchackathon/widgets/Login.dart';

class Root extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _RootState();
}

class _RootState extends State<Root>{

  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, User?>(
        builder: (context, user){
          if(user == null){
            //return LoginPage();
            return CustomerHome();
          }else if(user.type == User.DRIVER){
            return DriverHome();
          }else if(user.type == User.CUSTOMER){
            return CustomerHome();
          }else{
            return LoginPage();
          }
        },
        converter: (store){
          return store.state.user;
        });
  }
}