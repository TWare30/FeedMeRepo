import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import '../reducers/actions.dart';
import '../store/AppState.dart';
import '../middleware/Middleware.dart';

import '../store/AppState.dart';

class CaseSearch extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _CaseSearchState();
}

class _CaseSearchState extends State<CaseSearch>{

  TextEditingController caseIDCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    caseIDCtrl.text = 'DMOrg-Hackathon-Work-Order O-3';
    return Container(
      child: ListView(
        children: [
          TextField(
            controller: caseIDCtrl,
            decoration: InputDecoration(
                labelText: 'Case ID'
            ),
          ),
          StoreConnector<AppState, Store<AppState>>(
            converter: (store) => store,
            builder: (context, store) => TextButton(
              child: new Text("Search"),
              onPressed: ()=> store.dispatch(
                  {
                    'type': actionTypes.CASE_REQUEST,
                    'caseID': caseIDCtrl.text
                  }
              ),
            )
          ),
          StoreConnector<AppState, String>(
              converter: (store) => store.state.currentCase?.ID ?? '',
              builder: (context, caseID) => Text(
                  caseID
              )
          )
        ],
      )
    );
  }

}