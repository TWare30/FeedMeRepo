import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:srchackathon/store/AppState.dart';
import 'package:srchackathon/models/flutter/Cart.dart';

class CartBar extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _CartBarState();
}

class _CartBarState extends State<CartBar>{

  @override
  Widget build(BuildContext context) {

    return StoreConnector<AppState, Cart>(
      converter: (store) => store.state.cart,
      builder: (context, cart){
        if(cart.items.isEmpty){
          return SizedBox(height: 0.0);
        }else{
          return GestureDetector(
              onTap: () => this.openCart(),
              child: Container(
                  padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                  decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondary),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("Total: " + cart.subtotalString()
                          , style: Theme.of(context).textTheme.displayMedium!.copyWith(
                              color: Theme.of(context).colorScheme.onSecondary)),
                      Icon(Icons.shopping_cart, color: Colors.white, size: 35,)
                    ],
                  )
              )
          );
        }
      }
    );
  }

  void openCart(){
    /*Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CartView()),
    );*/
  }

}