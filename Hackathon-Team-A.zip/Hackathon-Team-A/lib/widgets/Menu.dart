import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:srchackathon/reducers/actions.dart';
import 'package:srchackathon/store/AppState.dart';

import '../models/flutter/MenuData.dart';
import 'ItemModal.dart';

class Menu extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _MenuState();
}

class _MenuState extends State<Menu>{
  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, Map>(
        converter: (store){
          return {
            'menu': store.state.menu,
            'loadMenu': () => store.dispatch({
              'type': actionTypes.MENU_REQUEST,
              'restaurantID': 'SRC-HACKCOSMOS-DATA-RESTAURANT 7478CC15-D198-46B8-B29C-CE9E9A21942E',
            })
          };
        },
        builder: (context, props){
          if(props['menu'] == null){
            props['loadMenu']();
            return const Text('Loading menu...');
          }else{
            return buildMenu();
          }
        }
    );
  }

  Widget buildMenu(){
    return StoreConnector<AppState, List<Item>>(
      converter: (store) => store.state.menu!.items,
      builder: (context, items) {
        return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              return ListTile(
                enabled: true,
                onTap: () => showItemDialog(items[index]),
                contentPadding: const EdgeInsets.fromLTRB(15, 7, 15, 7),
                title: Text(items[index].name,
                  textAlign: TextAlign.start,
                  style: Theme.of(context).textTheme.titleMedium
                ),
                subtitle:Text(items[index].description ?? '',
                  style: const TextStyle(
                      fontSize: 12.0,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.bold,
                      color:Colors.grey
                  ),),
                trailing: Text(("\$" + items[index].priceString()),
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                      fontSize: 20.0,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.bold,
                      color: Colors.black
                  ),
                )
              );
            }
        );
      }
    );
  }


  showItemDialog(Item item){
    showDialog(
        context: context,
        builder: (BuildContext context) => ItemModal(item)
    );
  }


}