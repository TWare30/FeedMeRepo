import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:srchackathon/models/flutter/MenuData.dart';
import 'package:srchackathon/models/flutter/Cart.dart';
import 'package:srchackathon/reducers/actions.dart';
import 'package:srchackathon/store/AppState.dart';

class ItemModal extends StatefulWidget {
  final Item menuItem;

  ItemModal(this.menuItem);

  @override
  State<StatefulWidget> createState() => _ItemModalState();
}

class _ItemModalState extends State<ItemModal> {
  late int _quantity;
  late double _price;
  late TextEditingController _notes;

  @override
  void initState() {
    super.initState();
    _quantity = 1;
    _price = widget.menuItem.price;
    _notes = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
        backgroundColor: Theme.of(context).colorScheme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(20.0)),
        ),
        child: SizedBox(
          height: 250.0,
          width: 300.0,
          child: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                SizedBox(
                  height: 35.0,
                ),
                Expanded(
                    flex: 3,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Text(widget.menuItem.name,
                            style: Theme.of(context).textTheme.titleMedium),
                        SizedBox(height: 25.0),
                        Column(children: <Widget>[
                          Text('Quantity',
                              style: Theme.of(context).textTheme.labelMedium),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              TextButton(
                                onPressed: _decrementQuantity,
                                child: Icon(Icons.remove,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onBackground),
                              ),
                              Text(_quantity.toString(),
                                  style:
                                      Theme.of(context).textTheme.displayMedium),
                              TextButton(
                                onPressed: _incrementQuantity,
                                child: Icon(Icons.add,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onBackground),
                              )
                            ],
                        ),
                      ]),
                      /*TextField(
                        controller: _notes,
                        maxLines: 2
                      )*/
                    ],
                  )),
              Container(
                width: double.infinity,
                height: 60.0,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(20.0),
                        bottomRight: Radius.circular(20.0)),
                    color: Theme.of(context).colorScheme.secondary),
                child: StoreConnector<AppState, Store>(
                  converter: (store) => store,
                  builder: (context, store) {
                    return TextButton(
                      onPressed: () => _addToCart(store),
                      child: Text(
                        'Add to Cart',
                        style: TextStyle(
                            color:
                                Theme.of(context).colorScheme.onSecondary),
                      ));
                  }),
              )
            ],
          )),
        ));
  }

  void _incrementQuantity() {
    if (_quantity < 10) {
      setState(() {
        _quantity++;
      });
    }
  }

  void _decrementQuantity() {
    if (_quantity > 1) {
      setState(() {
        _quantity--;
      });
    }
  }


  void _addToCart(Store store) {
    OrderItem item = OrderItem(
        widget.menuItem.pzInsKey,
        _quantity,
        (_quantity * widget.menuItem.price),
        _notes.text);
    store.dispatch({
      'type': actionTypes.CART_ADD_ITEM,
      'item': item
    });
    Navigator.pop(context);
  }
}
