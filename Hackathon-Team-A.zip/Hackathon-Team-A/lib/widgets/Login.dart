import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:validators/sanitizers.dart';
import 'package:validators/validators.dart';
import 'package:srchackathon/reducers/actions.dart';

import '../store/AppState.dart';
import '../utils/theme.dart';


class LoginPage extends StatefulWidget {
  LoginPage();

  @override
  State<StatefulWidget> createState() => new _LoginPageState();

}

class _LoginPageState extends State<LoginPage>{

  //User information
  String _username = '';
  String _password = '';
  String _name = '';
  String _email = '';
  String _phoneNumber ='';

  //Form information
  final formKey = new GlobalKey<FormState>();
  final passKey = new GlobalKey<FormFieldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: Container(
            padding: EdgeInsets.symmetric(vertical: 0.0, horizontal:  20.0),
            color: Theme.of(context).primaryColor,
            child: Form(
                key: formKey,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                          padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 0.0),
                          child: TextFormField(
                              decoration: InputDecoration(
                                  labelText: "Username",
                                  fillColor: Theme.of(context).backgroundColor,
                                  filled: true
                              ),
                              validator: (value) => (value == null || value.isEmpty) ? "Username is empty" : null,
                              onSaved: (value) => _username = value ?? ''
                          )
                      ),
                      Container(
                          padding: const EdgeInsets.fromLTRB( 0.0, 20.0, 0.0, 40.0),
                          child: TextFormField(
                            decoration: InputDecoration(
                                labelText: "Password",
                                fillColor: Theme.of(context).backgroundColor,
                                filled: true
                            ),
                            validator: (value) => (value == null || value.isEmpty) ? "Password is empty" : null,
                            onSaved: (value) => _password = value ?? '',
                            obscureText: true,
                          )
                      ),
                      StoreConnector<AppState, VoidCallback>(
                          converter: (store){
                            return () => login(store);
                          },
                          builder: (context, login){
                            return TextButton(
                                style: Skin.primaryButton,
                                onPressed: login,
                                child: Text('Login')
                            );
                          }
                      ),

                      TextButton(
                          style: Skin.secondaryButton,
                          child: const Text('Create an Account'),
                          onPressed: () => {}
                      )
                    ]
                )
            )
        )
    );
  }

  //Validates and Saves the form
  bool save(){
    final form = formKey.currentState;

    if(form != null && form.validate()){
      form.save();
      return true;
    }else{
      return false;
    }
  }

  //Attempts to log in with form data
  void login(Store store){
    if(save()){
      store.dispatch({
        'type': actionTypes.LOGIN_REQUEST,
        'username': _username,
        'password': _password
      });
    }
  }

}