import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:srchackathon/widgets/Menu.dart';
import 'package:srchackathon/widgets/CartBar.dart';

class CustomerHome extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FeedMe'),
        centerTitle: true,
      ),
      body: Menu(),
      bottomNavigationBar: CartBar(),
      primary: true,
    );
  }


}
