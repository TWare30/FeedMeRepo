class AssignmentAction{
  String? actionID;
  String? caseID;
  String? name;

  AssignmentAction.fromMap(Map<String, dynamic> map){
    actionID = map['actionID'];
    caseID = map['caseID'];
    name = map['name'];
  }
}