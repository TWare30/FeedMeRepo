class PegaObject{
  String? ID;
  String? name;
  String? pxObjClass;

  PegaObject.fromMap(Map<String, dynamic> map){
    ID = map['ID'];
    name = map['name'];
    pxObjClass = map['pxObjClass'];
  }

  static List<PegaObject> listFromMap(List<dynamic> list){
    List<PegaObject> objList = [];
    for (Map<String, dynamic> map in list) {objList.add(PegaObject.fromMap(map));}
    return objList;
  }
}


class CaseData extends PegaObject{
  String? status;
  String? caseTypeID;
  String? parentCaseID;
  String? stage;
  String? urgency;
  DateTime? createTime;
  String? createdBy;
  DateTime? lastUpdateTime;
  String? lastUpdatedBy;
  String? owner;
  PegaObject? content;
  List<PegaObject>? stages;
  ServiceLevelAgreement? SLA;
  List<CaseAssignment>? assignments;
  List<Action>? actions;

  CaseData.fromMap(Map<String, dynamic> map) : super.fromMap(map){
    status = map['status'];
    caseTypeID = map['caseTypeID'];
    parentCaseID = map['parentCaseID'];
    stage = map['stage'];
    urgency = map['urgency'];
    createTime = DateTime.parse(map['createTime']);
    createdBy = map['createdBy'];
    lastUpdateTime = DateTime.parse(map['lastUpdateTime']);
    lastUpdatedBy = map['lastUpdatedBy'];
    owner = map['owner'];
    content = map['content'] != null ? PegaObject.fromMap(map['content']) : null;
    stages = map['stages'] != null ? PegaObject.listFromMap(map['stages']) : null;
    SLA = map['SLA'] != null ? ServiceLevelAgreement.fromMap(map['SLA']) : null;
    assignments = map['assignments'] != null ? CaseAssignment.listFromMap(map['assignments']) : null;
    actions = map['action'] != null ? Action.listFromMap(map['action']) : null;
  }

}


class ServiceLevelAgreement{
  DateTime? stageSLAGoal;
  DateTime? stageSLADeadline;
  DateTime? overallSLAGoal;
  DateTime? overallSLADeadline;
  String? pxObjClass;

  ServiceLevelAgreement.fromMap(Map<String, dynamic> map){
    stageSLAGoal = map['stageSLAGoal'] != null ? DateTime.parse(map['stageSLAGoal']) : null;
    stageSLADeadline = map['stageSLADeadline'] != null ? DateTime.parse(map['stageSLADeadline']) : null;
    overallSLAGoal = map['overallSLAGoal'] != null ? DateTime.parse(map['overallSLAGoal']) : null;
    overallSLADeadline = map['overallSLADeadline'] != null ? DateTime.parse(map['overallSLADeadline']) : null;
    pxObjClass = map['pxObjClass'];
  }
}

class StartingProcess extends PegaObject{
  bool? requiresFieldsToCreate;

  StartingProcess.fromMap(Map<String, dynamic> map) : super.fromMap(map){
    requiresFieldsToCreate = map['requiresFieldsToCreate'];
  }
}

class CaseAssignment extends PegaObject{
  String? type;
  String? routedTo;
  String? instructions;
  DateTime? scheduledGoalTime;
  DateTime? executedGoalTime;
  DateTime? scheduledDeadlineTime;
  DateTime? executedDeadlineTime;
  String? urgency;
  List<Action>? actions;

  CaseAssignment.fromMap(Map<String, dynamic> map) : super.fromMap(map){
    type = map['type'];
    routedTo = map['routedTo'];
    instructions = map['instructions'];
    scheduledGoalTime = map['scheduledGoalTime'] != null ? DateTime.parse(map['scheduledGoalTime']) : null;
    executedGoalTime = map['executedGoalTime'] != null ?DateTime.parse(map['executedGoalTime']) : null;
    scheduledDeadlineTime = map['scheduledDeadlineTime'] != null ?DateTime.parse(map['scheduledDeadlineTime']) : null;
    executedDeadlineTime = map['executedDeadlineTime'] != null ?DateTime.parse(map['executedDeadlineTime']) : null;
    urgency = map['urgency'];
    actions = map['actions'] != null ? Action.listFromMap(map['actions']) : null;
  }

  @override
  static listFromMap(List<dynamic> list){
    List<CaseAssignment> objList = [];
    for (Map<String, dynamic> map in list) {
      objList.add(CaseAssignment.fromMap(map));
    }
    return objList;
  }

}

class Action extends PegaObject{

  Action.fromMap(Map<String, dynamic> map) : super.fromMap(map);

  @override
  static listFromMap(List<Map<String, dynamic>> list){
    List<Action> objList = [];
    for (Map<String, dynamic> map in list) {objList.add(Action.fromMap(map));}
    return objList;
  }
}