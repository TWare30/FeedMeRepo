class User{
  static const String DRIVER = 'driver';
  static const String CUSTOMER = 'customer';

  late String type;

  User.fromMap(Map<String, dynamic> map){

  }
}