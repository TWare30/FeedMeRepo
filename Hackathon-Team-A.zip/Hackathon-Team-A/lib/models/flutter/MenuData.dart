
import 'package:validators/sanitizers.dart';

class MenuData{
  String name = '';
  List<Item> items = [];

  MenuData.fromMap(Map<String, dynamic> map){
    name = map['Name'];
    items = Item.listFromMap(map['Items']);
  }
}

class Item {
  String name = '';
  String? description = '';
  late double price = 0.0;
  late String pzInsKey;
  bool? isPopular = false;

  Item.fromMap(Map<String, dynamic> map){
    name = map['Name'];
    description = map['Description'];
    price = toDouble(map['Price']);
    pzInsKey = map['pzInsKey'];
    isPopular = toBoolean(map['isPopular'] ?? 'false');
  }

  static List<Item> listFromMap(List<dynamic>? list){
    List<Item> objList = [];
    if(list != null){
      for (Map<String, dynamic> map in list) {objList.add(Item.fromMap(map));}
    }
    return objList;
  }


  String priceString(){
    return price.toStringAsFixed(2);
  }
}