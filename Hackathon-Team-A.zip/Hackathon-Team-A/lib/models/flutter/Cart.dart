
class Cart{
  List<OrderItem> items = [];
  double subtotal = 0.0;

  caculateSubtotal(){
    subtotal = 0.0;
    for(OrderItem item in items){
      subtotal = subtotal + item.price;
    }
  }

  String subtotalString(){
    return subtotal.toStringAsFixed(2);
  }

}

class OrderItem{
  String pzInsKey;
  int quantity;
  double price;
  String? notes;

  OrderItem(this.pzInsKey, this.quantity, this.price, [this.notes]);

  String priceString(){
    return price.toStringAsFixed(2);
  }
}