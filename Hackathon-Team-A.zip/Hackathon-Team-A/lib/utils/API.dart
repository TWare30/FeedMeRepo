import 'dart:collection';
import 'dart:convert';
import 'package:http/http.dart' as http;

class API{

  static const String _host = 'hackathon.srclogic.com';
  static const String _basePath = '/prweb/api/v1';
  static String _username = '';
  static String _password = '';
  static Map<String, String> _headers = {};

  static void setCredentials(String username, String password){
    _username = username;
    _password = password;
    _headers = {
      'Accept': 'application/json',
      'Authorization':
      'Basic ' + base64.encode(utf8.encode(_username + ':' + _password))
    };
  }

  static Future<Map<String, dynamic>> getCase(String caseID) async{
    var response = await http.get(Uri.https(_host, '$_basePath/cases/$caseID'), headers: _headers);
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> getAssignment(String assignmentID) async{
    var response = await http.get(Uri.https(_host, '$_basePath/assignments/$assignmentID'), headers: _headers);
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> getAssignmentAction(String assignmentID, String actionID) async{
    var response = await http.get(Uri.https(_host, '$_basePath/assignments/$assignmentID/actions/$actionID'), headers: _headers);
    print(response.statusCode);
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> login(String username, String password) async{
    setCredentials(username, password);
    var response = await http.get(Uri.https(_host), headers: _headers);
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> loadMenu(String restaurantID) async{
    var response = await http.get(
      Uri.https(
        _host,
        '$_basePath/data/D_MenuByRestaurantKey',
        {'RestaurantKey': restaurantID}
      ), headers: _headers);
    return json.decode(response.body);
  }

}