import 'package:flutter/material.dart';

  Color _primaryColor = Color(0xFFF02010);
  ColorScheme _colorScheme = ColorScheme(
      brightness: Brightness.light,
      primary: _primaryColor,
      onPrimary: Colors.white,
      secondary: Color(0xFF298BF0),
      onSecondary: Colors.white,
      error: Colors.amber,
      onError: Colors.white,
      background: Colors.white,
      onBackground: Colors.black,
      surface: Colors.white,
      onSurface: Colors.black
  );

ThemeData AppTheme(){


  return ThemeData(
    colorScheme: _colorScheme,
    buttonTheme: ButtonThemeData(
      buttonColor: _primaryColor,
    ),
    textTheme: TextTheme(
      titleMedium: TextStyle(
        fontSize: 20.0,
        fontFamily: 'Montserrat',
        fontWeight: FontWeight.bold
      ),
      labelMedium: TextStyle(
        fontFamily:  'sans-serif',
        fontSize: 18,
        color: _colorScheme.onBackground,
        decoration: TextDecoration.underline,
        decorationColor: _colorScheme.onBackground,
        decorationStyle: TextDecorationStyle.solid
      ),
      displayMedium: TextStyle(
          fontSize: 20.0,
          fontFamily: 'Montserrat'
      )
    ),
    fontFamily: 'Montserrat',
  );
}

class Skin{
  static ButtonStyle primaryButton = ButtonStyle();
  static ButtonStyle secondaryButton = ButtonStyle();
}